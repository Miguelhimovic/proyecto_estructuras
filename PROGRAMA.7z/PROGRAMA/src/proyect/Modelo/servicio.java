/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyect.Modelo;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public  class servicio {
    ArrayList  nombre_servicio;
    ArrayList valor;
    ArrayList codigo;

    public servicio(ArrayList nombre_servicio, ArrayList valor, ArrayList codigo) {
        this.nombre_servicio = nombre_servicio;
        this.valor = valor;
        this.codigo = codigo;
    }

    public ArrayList getNombre_servicio() {
        return nombre_servicio;
    }

    public void setNombre_servicio(ArrayList nombre_servicio) {
        this.nombre_servicio = nombre_servicio;
    }

    public ArrayList getValor() {
        return valor;
    }

    public void setValor(ArrayList valor) {
        this.valor = valor;
    }

    public ArrayList getCodigo() {
        return codigo;
    }

    public void setCodigo(ArrayList codigo) {
        this.codigo = codigo;
    }
    
    
    public  void Ingresarcodigo(String codigos){
       codigo.add(codigos);
    }
    public  void Ingresarnombre(String nombresc){
       nombre_servicio.add(nombresc);
    }
     public  void Ingresarvalor(String valores){
       valor.add(valores);
    }
     
     
     public void Eliminarcodigo(String codigos) {
        codigo.remove(codigo.indexOf(codigos)); 
        
      
    }
     public void Eliminarvalor(String valores) {
        valor.remove(valor.indexOf(valores)); 
        
      
    }
     public void Eliminarnombre(String nombresc) {
        nombre_servicio.remove(nombre_servicio.indexOf(nombresc)); 
        
      
    }
     
      public String Buscarnombre(String nombresc) {
      String buscarnombre="";
       if(nombre_servicio.contains(nombresc)==true){
           buscarnombre=nombre_servicio.get(nombre_servicio.indexOf(nombresc)).toString();
       } else {
           buscarnombre="no existe ";
       }
       return buscarnombre;
    }
       public String Buscarvalor(String valores) {
      String buscarvalor="";
       if(valor.contains(valores)==true){
           buscarvalor=valor.get(valor.indexOf(valores)).toString();
       } else {
           buscarvalor="no existe ";
       }
       return buscarvalor;
    }
        public String Buscarcodigo(String codigos) {
      String buscarcodigo="";
       if(codigo.contains(codigos)==true){
           buscarcodigo=codigo.get(codigo.indexOf(codigos)).toString();
       } else {
           buscarcodigo="no existe ";
       }
       return buscarcodigo;
    }


   
    
      
   
    
}
