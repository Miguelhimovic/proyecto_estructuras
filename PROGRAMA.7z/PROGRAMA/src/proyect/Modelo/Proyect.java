
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyect.Modelo;

/**
 *
 * @author Usuario
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import proyect.Vistas.menuprincipal;
import proyect.Vistas.menuprincipal;

/**
 *
 * @author Usuario
 */
public class Proyect {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        menuprincipal principal=new menuprincipal();
        principal.setVisible(true);
        
    }
}


